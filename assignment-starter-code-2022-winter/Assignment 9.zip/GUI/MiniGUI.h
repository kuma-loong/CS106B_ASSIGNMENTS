#pragma once

#include "ProblemHandler.h"
#include "GColorConsole.h"
#include "GUIMain.h"
#include "GUIUtils.h"
#include "TemporaryComponent.h"
#include "TextUtils.h"
#include "Core.h"
#include "ConsoleUtils.h"
